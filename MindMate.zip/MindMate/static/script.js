
async function sendMessage() {
    const inputBox = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');
    const userMessage = inputBox.value;
    chatBox.innerHTML += `<div><b>You:</b> ${userMessage}</div>`;
    inputBox.value = '';

    const response = await fetch('/ask', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ message: userMessage })
    });

    const data = await response.json();
    chatBox.innerHTML += `<div><b>MindMate:</b> ${data.reply}</div>`;
}
