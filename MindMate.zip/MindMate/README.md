
# MindMate - AI Mental Health Chatbot

MindMate is an AI-powered chatbot built using Flask and OpenAI's GPT API.
It helps users express their feelings and get emotionally supportive responses.

## How to Run

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Add your OpenAI API key in `app.py`:
```python
openai.api_key = "YOUR_API_KEY_HERE"
```

3. Start the server:
```
python app.py
```

4. Open your browser and go to `http://127.0.0.1:5000`
